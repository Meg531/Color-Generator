package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

public class MainController {
	
	@FXML
	private Button Submit;
	
	@FXML
	private AnchorPane Background;
	
	@FXML
	private TextField Question1;
	
	@FXML
	private TextField Question2;
	
	@FXML
	private TextField Question3;
	
	public void Submit(ActionEvent event) {
		
		Question1.clear();
		Question2.clear();
		Question3.clear();
		Alert a = new Alert(AlertType.NONE);
				a.setAlertType(AlertType.CONFIRMATION);
				a.show();;
	}
}
