package application.controller;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class Q1Controller {
	@FXML
	private Button oneButton;
	
	@FXML
	private Button twoButton;
	
	@FXML
	private Button threeButton;
	
	@FXML
	private Button fourButton;
	
	@FXML
	private Button fiveButton;
	
	@FXML
	private Button sixButton;
	
	@FXML
	private Button sevenButton;
	
	@FXML
	private Button eightButton;
	
	@FXML
	private Button nineButton;
	
	@FXML
	private Button tenButton;
	
	@FXML
	private Button backButton;
	
	/**
	 * 
	 * @param event
	 * @throws IOException
	 * 
	 * Start button should take user to ColorPurple.fxml
	 */
	public void oneButton(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/ColorPurple.fxml"));
		Scene scene = new Scene(root,600,400);
		Stage secondaryStage = (Stage)((Node)event.getSource()).getScene().getWindow();
		secondaryStage.setScene(scene);
		secondaryStage.show();
	}
	
	/**
	 * 
	 * @param event
	 * @throws IOException
	 * 
	 * Start button should take user to ColorNavy.fxml
	 */
	public void twoButton(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/ColorNavy.fxml"));
		Scene scene = new Scene(root,600,400);
		Stage secondaryStage = (Stage)((Node)event.getSource()).getScene().getWindow();
		secondaryStage.setScene(scene);
		secondaryStage.show();
	}
	
	/**
	 * 
	 * @param event
	 * @throws IOException
	 * 
	 * Start button should take user to ColorBlue.fxml
	 */
	public void threeButton(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/ColorBlue.fxml"));
		Scene scene = new Scene(root,600,400);
		Stage secondaryStage = (Stage)((Node)event.getSource()).getScene().getWindow();
		secondaryStage.setScene(scene);
		secondaryStage.show();
	}
	
	/**
	 * 
	 * @param event
	 * @throws IOException
	 * 
	 * Start button should take user to ColorYellow.fxml
	 */
	public void fourButton(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/ColorYellow.fxml"));
		Scene scene = new Scene(root,600,400);
		Stage secondaryStage = (Stage)((Node)event.getSource()).getScene().getWindow();
		secondaryStage.setScene(scene);
		secondaryStage.show();
	}
	
	/**
	 * 
	 * @param event
	 * @throws IOException
	 * 
	 * Start button should take user to ColorSB.fxml
	 */
	public void fiveButton(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/ColorSB.fxml"));
		Scene scene = new Scene(root,600,400);
		Stage secondaryStage = (Stage)((Node)event.getSource()).getScene().getWindow();
		secondaryStage.setScene(scene);
		secondaryStage.show();
	}
	
	/**
	 * 
	 * @param event
	 * @throws IOException
	 * 
	 * Start button should take user to ColorPink.fxml
	 */
	public void sixButton(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/ColorPink.fxml"));
		Scene scene = new Scene(root,600,400);
		Stage secondaryStage = (Stage)((Node)event.getSource()).getScene().getWindow();
		secondaryStage.setScene(scene);
		secondaryStage.show();
	}
	
	/**
	 * 
	 * @param event
	 * @throws IOException
	 * 
	 * Start button should take user to ColorY.fxml
	 */
	public void sevenButton(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/ColorY.fxml"));
		Scene scene = new Scene(root,600,400);
		Stage secondaryStage = (Stage)((Node)event.getSource()).getScene().getWindow();
		secondaryStage.setScene(scene);
		secondaryStage.show();
	}
	
	/**
	 * 
	 * @param event
	 * @throws IOException
	 * 
	 * Start button should take user to ColorYG.fxml
	 */
	public void eightButton(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/ColorYG.fxml"));
		Scene scene = new Scene(root,600,400);
		Stage secondaryStage = (Stage)((Node)event.getSource()).getScene().getWindow();
		secondaryStage.setScene(scene);
		secondaryStage.show();
	}
	
	/**
	 * 
	 * @param event
	 * @throws IOException
	 * 
	 * Start button should take user to ColorRed.fxml
	 */
	public void nineButton(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/ColorRed.fxml"));
		Scene scene = new Scene(root,600,400);
		Stage secondaryStage = (Stage)((Node)event.getSource()).getScene().getWindow();
		secondaryStage.setScene(scene);
		secondaryStage.show();
	}
	
	/**
	 * 
	 * @param event
	 * @throws IOException
	 * 
	 * Start button should take user to ColorBlack.fxml
	 */
	public void tenButton(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/ColorBlack.fxml"));
		Scene scene = new Scene(root,600,400);
		Stage secondaryStage = (Stage)((Node)event.getSource()).getScene().getWindow();
		secondaryStage.setScene(scene);
		secondaryStage.show();
	}
	
	/**
	 * 
	 * @param event
	 * @throws IOException
	 * 
	 * Start button should take user to ColorBlack.fxml
	 */
	public void backButton(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/Start.fxml"));
		Scene scene = new Scene(root,600,400);
		Stage secondaryStage = (Stage)((Node)event.getSource()).getScene().getWindow();
		secondaryStage.setScene(scene);
		secondaryStage.show();
	}
}
