package application.controller;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class moodChartController {

	
	@FXML
	private Button moodChart;
	
	/**
	 * 
	 * @param event
	 * @throws IOException
	 * 
	 * Start button should take user to MoodChart.fxml
	 */
	public void moodChart(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/MoodChart.fxml"));
		Scene scene = new Scene(root,600,400);
		Stage secondaryStage = (Stage)((Node)event.getSource()).getScene().getWindow();
		secondaryStage.setScene(scene);
		secondaryStage.show();
	}
}
