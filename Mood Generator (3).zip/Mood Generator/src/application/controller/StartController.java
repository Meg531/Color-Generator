package application.controller;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class StartController {
	@FXML
	private Button startButton;
	
	/**
	 * 
	 * @param event
	 * @throws IOException
	 * 
	 * Start button should take user to Q1.fxml
	 */
	public void startButton(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/Q1.fxml"));
		Scene scene = new Scene(root,600,400);
		Stage secondaryStage = (Stage)((Node)event.getSource()).getScene().getWindow();
		secondaryStage.setScene(scene);
		secondaryStage.show();
	}
}
